package tp.controleur;

import tp.modele.*;
import tp.modele.TLexeme.Nature;

/**
 * Cette classe permet de convertir une expression infixée en une File d'objets
 * de type Lexeme.
 * 
 * @author Michel Devaux
 * @version 1.1
 */
class Analyseur {

	// Constantes
	private final String CHIFFRES = "0123456789";
	private final String SIGNES = "+-*/";
	private final String PARENTHESES = "()";

	// File contenant en fin de traitement les éléments de l'expression.
	private File<TLexeme> infixe;
	// Structure schématique de l'expression. Ex : ((6*5)+3) -> ((n.n).n)
	private String structure;
	// Autorise ou non quelques tolérances dans la gestion des parenthèses
	private boolean tolerant = true;

	/**
	 * Getter de l'attribut "tolerant".
	 * @return TRUE si "tolerant" est actif.
	 */
	public boolean isTolerant() {
		return tolerant;
	}

	/**
	 * Active ou non la tolérance de l'Analyseur
	 * @param tolerant
	 */
	public void setTolerant(boolean tolerant) {
		this.tolerant = tolerant;
	}

	/**
	 * Obtient, en les analysant, la liste des elements qui composent
	 * l'expression et les range dans une File d'éléments de type TLexeme.
	 * 
	 * @return Instance de la classe File.
	 * @param expression Expression de type String à traiter.
	 * 
	 * @throws Exception
	 * Retourne une exception de structure, arithmétique ou de dépassement de capacité
	 */
	public File<TLexeme> getFileInfixe(String expression)
			throws ExceptionStruct, ExceptionMath {
		// Déclarations
		infixe = new File<TLexeme>();
		TLexeme elt;
		structure = "";
		int i = 0;
		//
		// Expression vide
		if (expression.equals("")) {
			throw new ExceptionStruct("L'expression est vide.");
		}
		//
		while (i < expression.length()) {
			// Caractère en cours
			String str = expression.substring(i, i + 1);
			//
			// Traitement des chiffres
			if (CHIFFRES.indexOf(str) != -1) {
				// Former le nombre en recherchant les chiffres suivants
				while (i + 1 < expression.length()
						&& CHIFFRES.indexOf(expression.substring(i + 1, i + 2)) != -1) {
					i++;
					str += expression.substring(i, i + 1);
				}
				// Tester si le nombre ne dépasse pas la capacité d'un entier
				try {
					int test = Integer.parseInt(str);
				} catch (NumberFormatException e) {
					// Lever une ExceptionMath
					throw new ExceptionMath("L'expression contient des opérandes trop grands.");
				}
				elt = new TLexeme();
				elt.valeur = str;
				elt.nature = Nature.operande;
				infixe.enfiler(elt);
				// Ajouter la représentation d'un opérande à la structure
				structure += "n";
			}
			//
			// Traitement des opérateurs
			else if (SIGNES.indexOf(str) != -1) {
				// Ajouter l'opérateur dans la File
				elt = new TLexeme();
				elt.valeur = str;
				elt.nature = Nature.operateur;
				infixe.enfiler(elt);
				// Ajouter la représentation d'un opérateur à la structure
				structure += ".";
			}
			//
			// Traitement des parenthèses
			else if (PARENTHESES.indexOf(str) != -1) {
				// Ajouter la parenthèse dans la File
				elt = new TLexeme();
				elt.valeur = str;
				elt.nature = (str.equals("(")) ? Nature.parenthese_ouvrante
						: Nature.parenthese_fermante;
				infixe.enfiler(elt);
				// Ajouter la parenthèse à la structure
				structure += str;
			}
			//
			// Ignorer les espaces
			else if (str.equals(" ")) {
				// On ne fait rien là...
			}
			//
			// Sinon str = caractère non autorisé
			else {
				throw new ExceptionStruct(
					"L'expression contient des caractères non autorisés.");
			}
			// Incrémenter le pointeur
			i++;
		}
		// Vérifier la struture
		if (!verifierStructure()) {
			throw new ExceptionStruct("L'expression n'est pas correcte." 
					+ "\nVérifiez le compte des parenthèses, opérandes et opérateurs.");
		}
		// Retourner la File
		return infixe;
	}

	/**
	 * Vérifie la structure de l'expression en la réduisant progressivement.<br/>
	 * La structure complètement réduite doit être égale à "n".<br/>
	 * Exemple : (n.(n.n)) -> (n.n) -> n
	 * 
	 * @return TRUE si la structure est correcte.
	 */
	private boolean verifierStructure() {
		// Déclarations
		String chaine = structure;
		String recherche = "(n.n)";
		String remplace = "n";
		//
		// Tolérer optionnellement en entrée quelques libertés avec la syntaxe
		if (tolerant) {
			// Ajoute des parenthèses autour de l'expression : 5*2 -> (5*2)
			chaine = "(" + chaine + ")";
			// Supprime les parenthèses excédentaires autour d'un nombre seul
			chaine = chaineCorrigee(chaine);
		}
		//
		// Boucle principale assurant les conversions : (n.n) -> n
		while (chaine.indexOf(recherche) != -1) {
			// Remplacer
			chaine = chaine.replace(recherche, remplace);
			// Tolérance
			if (tolerant) chaine = chaineCorrigee(chaine);
		}	
		// Tolérer optionnellement en sortie quelques libertés avec la syntaxe
		if (tolerant) chaine = chaineCorrigee(chaine);
		//
		// Affiche le résultat dans la console. Doit être égal à : n
		boolean resultat = chaine.equals(remplace);
		String format = "RESULTAT DE L'ANALYSE LEXICALE : %s = %s";
		System.out.println(String.format(format, structure, chaine));
		//
		// Renvoie le résultat de l'analyse
		return resultat;
	}
	
	/**
	 * Supprime les parenthèses excédentaires autour d'un nombre seul <br/>
	 * (n) -> n
	 * @param chaine
	 * @return
	 */
	private String chaineCorrigee(String chaine) {
		while (chaine.indexOf("(n)") != -1) {
			chaine = chaine.replace("(n)", "n");
		}
		return chaine;
	}
	

}
