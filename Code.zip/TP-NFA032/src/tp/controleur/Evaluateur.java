package tp.controleur;

import tp.modele.*;
import tp.modele.TLexeme.Nature;

/**
 * Cette classe contient des méthodes de traitement et de resolution d'une
 * expression infixee.
 * 
 * @author Michel Devaux
 * @version 1.4
 */
public class Evaluateur implements IEvaluateur {
	
	// Instance de l'interface de la classe (Singleton)
	private static IEvaluateur evaluateur;
	// Instance de l'Analyseur
	private Analyseur analyseur;
	
	/**
	 * Le constructeur privé protège la classe qui n'est accessible que par
	 * son Singleton. 
	 * Ce Singleton renvoie l'Instance unique de l'Interface liée.
	 */
	private Evaluateur() {
		analyseur = new Analyseur();
	}

	/**
	 * Singleton de l'Evaluateur
	 * @return Instance unique de type IEvaluateur.
	 */
	public static IEvaluateur getEvaluateur() {
		if (evaluateur == null) {
			evaluateur = new Evaluateur();
		}
		return evaluateur;
	}
	
	/**
	 * Active ou non la tolérance de l'Analyseur
	 * @param tolerant
	 */
	public void setTolerance(boolean tolerant) {
		analyseur.setTolerant(tolerant);
	}

	/**
	 * Utilise une instance de la classe Analyseur pour analyser une expression
	 * et placer les éléments qui la composent dans une File d'éléments de type
	 * Lexeme.
	 * 
	 * @param expression Chaine représentant l'expression à analyser
	 * @return File d'éléments de type TLexeme
	 * @throws Exception Répercute les exceptions levées par la classe Analyseur.
	 * @see    Analyseur#getFileInfixe(String)
	 */
	private File<TLexeme> analyser(String expression) 
			throws ExceptionStruct, ExceptionMath {
		File<TLexeme> infixe = analyseur.getFileInfixe(expression);
		return infixe;
	}

	/**
	 * Convertit une expression infixée en expression post-fixée.<br/>
	 * Les paramètres d'entrée et sortie sont des Files.
	 * 
	 * @param file File d'éléments de type TLexeme
	 * @return File d'éléments de type TLexeme
	 */
	private File<TLexeme> convertir(File<TLexeme> infixe) {
		// Création de la File de sortie
		File<TLexeme> postfixe = new File<TLexeme>();
		// Création de la Pile qui stockera parenthèses et opérateurs
		Pile<TLexeme> maPile = new Pile<TLexeme>();
		// Déclarations
		TLexeme elt;
		//
		// C'est parti !!!
		while (!infixe.fileVide()) {
			// Lire l'élément de tête et l'enlever de la File
			elt = infixe.lireFile();
			infixe.defiler();
			// En fonction de la nature de l'élément...
			switch (elt.nature) {
			case operande:
				// C'est un opérande...
				// On l'ajoute à la File postfixée.
				postfixe.enfiler(elt);
				break;
			case operateur:
				// C'est un opérateur...
				// On l'empile.
				maPile.empiler(elt);
				break;
			case parenthese_ouvrante:
				// C'est une parenthèse ouvrante...
				// On l'empile.
				maPile.empiler(elt);
				break;
			case parenthese_fermante:
				// C'est une parenthèse fermante...
				// Dépiler la pile jusque la parenthèse ouvrante.
				// Les éléments lus sont ajoutés à la File de sortie.
				elt = maPile.lirePile();
				while (elt.nature != Nature.parenthese_ouvrante) {
					postfixe.enfiler(elt);
					maPile.depiler();
					elt = maPile.lirePile();
				}
				// Dépiler la parenthèse ouvrante
				maPile.depiler();
				break;
			}
		}
		// Vider le reste de la pile (les opérateurs restants).
		while (!maPile.pileVide()) {
			elt = maPile.lirePile();
			postfixe.enfiler(elt);
			maPile.depiler();
		}
		// Retourner la File
		return postfixe;
	}

	/**
	 * L'automate retourne le calcul d'une expression post-fixée passée sous la
	 * forme d'une File d'éléments de type TLexeme.
	 * 
	 * @param postfixe File d'éléments de type TLexeme ordonnés en expression postfixée.
	 * @return Entier résultant du calcul de l'expression passée en paramètre.
	 * @throws Exception Répercute l'exception levée par une division par zéro
	 * ou par un dépassement de capacité
	 */
	private int automate(File<TLexeme> postfixe) throws ExceptionMath {
		// Création de la Pile qui stockera les opérandes
		Pile<TLexeme> maPile = new Pile<TLexeme>();
		// Déclarations
		int val1;
		int val2;
		int val3;
		long lVal;
		TLexeme elt;
		//
		// C'est parti !!!	
		while (!postfixe.fileVide()) {
			// Lire l'élément de tête et l'enlever de la File.
			elt = postfixe.lireFile();
			postfixe.defiler();
			// En fonction de la nature de l'élément...
			switch (elt.nature) {
			case operande:
				// C'est un opérande...
				// On l'empile.
				maPile.empiler(elt);
				break;
			case operateur:
				// C'est un opérateur... 
				// Dépiler les 2 opérandes concernés par l'opération.
				val2 = Integer.parseInt(maPile.lirePile().valeur);
				maPile.depiler();
				val1 = Integer.parseInt(maPile.lirePile().valeur);
				maPile.depiler();
				// Effectuer le calcul approprié.
				if (elt.valeur.equals("+")) {
					// Addition
					val3 = val1 + val2;
					// Vérifier si le résultat ne provoque pas un débordement de int
					if (((long)val1 + (long)val2) != val3){
						throw new ExceptionMath("L'expression provoque un dépassement de capacité.");
					}
				}
				else if (elt.valeur.equals("-")) {
					// Soustraction
					val3 = val1 - val2;
					// Vérifier si le résultat ne provoque pas un débordement de int
					if (((long)val1 - (long)val2) != val3){
						throw new ExceptionMath("L'expression provoque un dépassement de capacité.");
					}
				}
				else if (elt.valeur.equals("*")) {
					// Multiplication
					val3 = val1 * val2;
					// Vérifier si le résultat ne provoque pas un débordement de int
					if (((long)val1 * (long)val2) != val3){
						throw new ExceptionMath("L'expression provoque un dépassement de capacité.");
					}
				}
				else {
					// Division
					if (val2 != 0) {
						val3 = val1 / val2;
					}
					else {
						// Division par zéro... renvoyer une ExceptionMath
						throw new ExceptionMath("L'expression provoque une division par zéro.");
					}
					// Vérifier si le résultat ne provoque pas un débordement de int
					if (((long)val1 / (long)val2) != val3){
						throw new ExceptionMath("L'expression provoque un dépassement de capacité.");
					}
				}					
				// Affecter à elt une nouvelle instance de TLexeme
				// ayant pour valeur le résultat de l'opération.
				elt = new TLexeme();
				elt.valeur = "" + val3;
				elt.nature = Nature.operande;
				// Empiler le résulat elt.
				maPile.empiler(elt);;
				break;
			default:
				break;
			}
		}
		// Récupérer le résultat final de l'opération dans la Pile
		elt = maPile.lirePile();
		val1 = Integer.parseInt(elt.valeur);		
		// Retourner la valeur en tant qu'entier
		return val1;
	}

	/**
	 * Effectue le calcul d'une expression passée en paramètre
	 * en utilisant successivement l'analyseur, le convertisseur
	 * et l'automate à Pile.
	 * 
	 * @param expression Expression infixée. Exemple : ((5+3)*6)
	 * @return Résultat de type entier.
	 * @throws Exception Répercute l'exception levée par l'Analyseur ou
	 * par une des trois méthodes invoquées.
	 */
	@Override
	public int traitement(String expression) 
			throws ExceptionStruct, ExceptionMath  {
		int rtn = 0;
		File<TLexeme> maFile = null;
		System.out.println(expression);
		// Analyse de l'expression.
		maFile = analyser(expression);
		System.out.println("FILE EVALUATEUR : " + maFile);
		// Conversion en expression postfixée.
		maFile = convertir(maFile);
		System.out.println("FILE CONVERTISSEUR : " + maFile);
		// Utilisation de l'automate pour effectuer le calcul.
		rtn = automate(maFile);
		System.out.println("RESULTAT AUTOMATE : " + rtn);
		// Retourner le résulat.
		return rtn;
	}

}
