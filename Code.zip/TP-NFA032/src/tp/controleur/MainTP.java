package tp.controleur;

import tp.vue.*;

/**
 * Classe de lancement du programme.</br> Contient la méthode "main".
 * 
 * @author Michel Devaux
 * @version 1.0
 */
public class MainTP {

	private static boolean modeGraphique = true;

	/**
	 * Première méthode lancée par le programme.
	 * 
	 * @param args  optionnellement passés à la méthode.
	 */
	public static void main(String[] args) {
		if (modeGraphique) {
			// Mode Graphique
			new IHMGraphique();
		} else {
			// Mode Console
			IHMConsole ihm = new IHMConsole();
			ihm.saisir();
		}
	}

}
