package tp.controleur;

import tp.modele.*;

/**
 * Interface de l'Evaluateur.<br/>
 * Ne laisse apparaître que la seule méthode Calculer.
 * 
 * @author Michel
 * @version 1.0
 */
public interface IEvaluateur {
	public int traitement(String expression) 
			throws ExceptionStruct, ExceptionMath;
	public void setTolerance(boolean tolerance);
}
