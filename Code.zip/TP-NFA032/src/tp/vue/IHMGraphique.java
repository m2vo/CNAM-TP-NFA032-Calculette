package tp.vue;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import tp.controleur.*;

/**
 * Fenêtre de saisie utilisant Swing.
 * 
 * @author Michel Devaux
 * @version 1.6
 */
public class IHMGraphique extends JFrame {
	
	private Font font = new Font("Calibri", Font.PLAIN, 16);
	// Principaux contrôles
	private TextFieldFiltre txtExpression;
	private JCheckBox chkFiltre;
	private TextAreaScrollable zoneResultats;
	// ActionListener unique pour tous les contrôles 
	private ActionEvnt actionEvnt = new ActionEvnt();
	// Identificateurs : pour chacun des contrôles invoquant l'ActionListener
	private final String TXTEXPRESSION_EVNT = "0001";
	private final String BTNVALIDER_EVNT = "0002";
	private final String BTNEFFACER_EVNT = "0003";
	private final String CHKFILTRE_EVNT = "0004";
	
	/**
	 * Création de la fenêtre et de ses composants
	 */
	public IHMGraphique() {
		// Quitter l'application à la fermeture de la fenêtre
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Taille
		setPreferredSize(new Dimension(600, 400));
		// Nom
		setTitle("TP-NFA032-Michel Devaux");
		// Pas de redimensionnement
		setResizable(false);
		// Définir un layout au centre avec 20 px de margin H et V
		setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
		//
		// Définir le panel principal
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER,0,0));
		// Definir la taille préférée du panel principal
		panel.setPreferredSize(new Dimension(540, 320));
		add(panel);
		//
		// Les contrôles...
		// Titre Expression
		JLabel lbl = new JLabel("Entrez ci-dessous votre expression, puis validez :");
		lbl.setPreferredSize(new Dimension(500, 40));
		lbl.setFont(font);
		panel.add(lbl);
		// Champ d'édition Expression
		txtExpression = new TextFieldFiltre();
		txtExpression.setPreferredSize(new Dimension(500, 40));
		txtExpression.setHorizontalAlignment(JTextField.CENTER);
		txtExpression.setFont(font);
		txtExpression.setActionCommand(TXTEXPRESSION_EVNT);
		txtExpression.addActionListener(actionEvnt);
		txtExpression.setFiltrer(false);
		txtExpression.setCaracteresAutorises("0123456789+-*/()");
		panel.add(txtExpression);
		// Label vide (pour aérer)
		lbl = new JLabel(" ");
		lbl.setPreferredSize(new Dimension(500, 10));
		panel.add(lbl);
		// Case à cocher Filtrer
		chkFiltre = new JCheckBox();
		chkFiltre.setText("Filtrer les caractères de l'expression en entrée");
		chkFiltre.setFont(font);
		chkFiltre.setPreferredSize(new Dimension(340, 30));
		chkFiltre.setSelected(txtExpression.isFiltrer());
		chkFiltre.setActionCommand(CHKFILTRE_EVNT);
		chkFiltre.addActionListener(actionEvnt);
		panel.add(chkFiltre);
		// Bouton Effacer
		JButton btn = new JButton();
		btn.setText ("Effacer");
		btn.setPreferredSize(new Dimension(75, 30));
		btn.setActionCommand(BTNEFFACER_EVNT);
		btn.addActionListener(actionEvnt);
		panel.add(btn);
		// Label vide (pour aérer)
		lbl = new JLabel("");
		lbl.setPreferredSize(new Dimension(10, 20));
		panel.add(lbl);
		// Bouton Valider
		btn = new JButton();
		btn.setText ("Valider");
		btn.setPreferredSize(new Dimension(75, 30));
		btn.setActionCommand(BTNVALIDER_EVNT);
		btn.addActionListener(actionEvnt);
		panel.add(btn);
		// Label vide (pour aérer)
		lbl = new JLabel("");
		lbl.setPreferredSize(new Dimension(500, 20));
		panel.add(lbl);
		// Titre Resultats
		lbl = new JLabel("Résultats :");
		lbl.setFont(font);
		lbl.setPreferredSize(new Dimension(500, 30));
		panel.add(lbl);		
		// TextAreaScrollable Resultats
        zoneResultats = new TextAreaScrollable(new Dimension(500, 135));
        JTextArea area = zoneResultats.getTextArea();
		area.setFont(font);
		area.setEditable(false);  
        panel.add(zoneResultats);       
		// Laisser à Swing le soin d'optimiser la fenêtre
		pack();
		// Centrer la fenêtre dans l'écran
		setLocationRelativeTo(null);
		// Afficher la fenêtre
		setVisible(true);		
	}
	
	/**
	 * Lance le calcul de l'expression.<br/>
	 * Le résultat est placé dans zoneResultats. 
	 * La méthode gère les erreurs renvoyées par l'Evaluateur (fenêtre d'erreur)
	 */
	private void valider() {
		// Récupère l'expression dans le JTextField
		String expression = txtExpression.getText();
		// Try catch pour gérer à cet endroit une erreur éventuelle
		try {
			// Récupère le singleton de la classe Evaluateur
			IEvaluateur evaluateur = Evaluateur.getEvaluateur();
			// Mettre la tolérance à false (option)
			// evaluateur.setTolerance(false); 
			int calcul = evaluateur.traitement(expression);
			// Récupérer le JTextArea de la zoneResultats
			JTextArea area = zoneResultats.getTextArea();
			// Ajouter le résultat
			String resultat = expression + " = " + calcul;
			area.setText(area.getText() + resultat + "\n");	
		} catch (Exception e) {
			// Une erreur ! Afficher le message dans une fenêtre de dialogue
			JOptionPane.showMessageDialog(this, e.getMessage(), 
					"Calcul non réalisable", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	/**
	 * Effacer le contenu du champ d'édition
	 */
	private void effacer() {
		txtExpression.setText("");
	}

	
	/**
	 * Classe privée.<br/>
	 * Représente un évènement de type ActionListener
	 * 
	 * @author Michel
	 * @version 1.1
	 */
	private class ActionEvnt implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			// Récupérer l'ActionCommand pour identifier la source
			String action = e.getActionCommand();
			// Si clic sur Valider ou touche ENTER dans txtExpression 
			if (action.equals(BTNVALIDER_EVNT) || action.equals(TXTEXPRESSION_EVNT) ) {
				valider();
			}
			// Si clic sur chkFiltre
			if (action.equals(CHKFILTRE_EVNT)) {
				txtExpression.setFiltrer(chkFiltre.isSelected());
			}
			// Si clic sur Effacer
			if (action.equals(BTNEFFACER_EVNT)) {
				effacer();
			}
		}	
	}
	
	
}