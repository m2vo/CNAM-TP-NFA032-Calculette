package tp.vue;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;

/**
 * Représente un JTextField avec filtrage des caractères
 * 
 * @author Michel Devaux
 * @version 1.1
 */
public class TextFieldFiltre extends JTextField {

	private String caracteresAutorises = "";
	private boolean filtrer = false;

	public TextFieldFiltre() {
		// Supprimer le Copier/Coller
		setTransferHandler(null);
		// Ajouter un KeyListener pour filtrer les caractères entrants
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				if (filtrer && !caracteresAutorises.equals("")) {
					char c = e.getKeyChar();
					if (caracteresAutorises.indexOf("" + c) == -1)
						e.consume();
				}
			}
			@Override
			public void keyReleased(KeyEvent e) {}
			@Override
			public void keyPressed(KeyEvent e) {}
		});
	}

	/**
	 * Renvoie les caractères autorisés par le filtre
	 * @return Chaîne contenant les caractères autorisés
	 */
	public String getCaracteresAutorises() {
		return caracteresAutorises;
	}

	/**
	 * Détermine les caractères autorisés par le filtre
	 * @param caracteresAutorises  Chaîne contenant les caractères autorisés
	 */
	public void setCaracteresAutorises(String caracteresAutorises) {
		this.caracteresAutorises = caracteresAutorises;
	}

	/**
	 * Renvoie l'état du filtrage
	 * @return TRUE si le filtre est actif
	 */
	public boolean isFiltrer() {
		return filtrer;
	}
	
	/**
	 * Active ou désactive le filtre
	 * @param filtrer Vrai : active le filtre
	 */
	public void setFiltrer(boolean filtrer) {
		this.filtrer = filtrer;
		if (filtrer)
			filtrerTexte();
	}
	
	/**
	 * Filtre le texte déjà entré pour ne conserver que les caractères autorisés.
	 */
	private void filtrerTexte() {
		String texte = getText();
		String nouveau = "";
		for (char c : texte.toCharArray()) {
			if (caracteresAutorises.indexOf("" + c) != -1) {
				nouveau += c;
			}
		}
		setText(nouveau);
	}

}
