 package tp.vue;

import java.awt.*;
import javax.swing.*;

/**
 * Représente un Panel contenant un TextArea associé à un ScrollPane.
 * 
 * @author Michel Devaux
 * @version 1.0
 */
public class TextAreaScrollable extends JPanel {
	
	private JTextArea textArea;

	/**
	 * Initialise une instance de la classe.
	 * @param dimensions Taille de la zone.
	 */
	public TextAreaScrollable(Dimension dimensions) {
		setPreferredSize(dimensions);
		// Créer un layout dans lequel le TextArea prendra tout l'espace
		GridLayout layout = new GridLayout(1,1);
		setLayout(layout);		
		// Créer le JTextArea
		textArea = new JTextArea();
		// Créer le ScrollPane associé
		JScrollPane scroll = new JScrollPane(textArea);
		scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		// Ajouter le ScrollPane au composant
		add(scroll);
	}

	/**
	 * Récupère le TextArea associé au composant.<br/>
	 * Permet de paramétrer le TextArea : fonte, couleur, éditable, etc.
	 * @return
	 */
	public JTextArea getTextArea() {
		return textArea;
	}


}
