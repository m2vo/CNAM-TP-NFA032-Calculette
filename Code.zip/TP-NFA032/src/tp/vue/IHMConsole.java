package tp.vue;

import tp.controleur.*;
import tp.modele.*;

import java.util.Scanner;

/**
 * Première interface de saisie en mode console.
 * 
 * @author Michel Devaux
 * @version 1.0.0
 */
public class IHMConsole {
	
	public void saisir() {
		Scanner sc = new Scanner(System.in);
		String expression = sc.next();
		//
		try {
			IEvaluateur evaluateur = Evaluateur.getEvaluateur();
			int resultat = evaluateur.traitement(expression);
			System.out.println(expression + " = " + resultat);
		} catch (ExceptionStruct e) {
			System.out.println(e.getMessage());
		} catch (ExceptionMath e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}

}
