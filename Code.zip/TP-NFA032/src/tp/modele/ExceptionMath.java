package tp.modele;

/**
 * Représente une exception de arithmétique ou de dépassement de capacité
 * @author Michel Devaux
 * @version 1.0.0
 */
public class ExceptionMath extends Exception {
	
	/**
	 * Crée une instance de la classe avec un message générique.
	 */
	public ExceptionMath(){
		super("Erreur non identifiée !");
	}
	
	/**
	 * Crée une instance de la classe  avec un message personnalisé.
	 * @param message Message décrivant l'exception levée.
	 */
	public ExceptionMath(String message){
		super(message);
	}
}
