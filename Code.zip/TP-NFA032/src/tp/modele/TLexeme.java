package tp.modele;

/**
 * Represente un element d'une expression 
 * @author Michel Devaux
 * @version 1.0.0
 */
public class TLexeme {

	/**
	 * Définit la nature du lexeme
	 */
	public enum Nature {
		operande,
		operateur,
		parenthese_ouvrante,
		parenthese_fermante;
	}
	
	/**
	 * Attributs
	 */	
	public String valeur;
	public Nature nature;
	
	/**
	 * Redéfinit la méthode toString()
	 * @return Chaîne représentant la valeur de l'expression
	 */
	public String toString() {
		return this.valeur;
	}
	
}
