package tp.modele;


/**
 * Représente une collection d'objets de type générique chaînés sur le principe
 * LIFO (dernier entré, premier sorti).
 * 
 * @author Michel Devaux
 * @version 1.2
 * @param <E> Type générique
 */
public class Pile<E> {

	/**
	 * Classe privée.</br> Représente un élément de la Pile composé <br/>
	 * - d'une valeur de type générique <br/>
	 * - d'une référence à l'élément suivant.
	 */
	private class Element {
		public E valeur;
		public Element suivant;
	}

	/**
	 * Attributs
	 */
	private Element tete;

	/**
	 * Constructeur <br/>
	 * Crée un nouvel objet de type Pile.
	 */
	public Pile() {
		tete = null;
	}

	/**
	 * Teste si la pile est vide.
	 * @return TRUE si la pile est vide.
	 */
	public boolean pileVide() {
		return (tete == null);
	}

	/**
	 * Renvoie l'élément supérieur de la pile (le dernier élément entré).
	 * @return Objet de type générique.</br> 
	 * Retourne NULL si la pile est vide.
	 */
	public E lirePile() {
		E valeur = null;
		if (!pileVide()) {
			valeur = tete.valeur;
		}
		return valeur;
	}

	/**
	 * Empile un nouvel élément au sommet de la pile
	 * @param elt Objet de type générique.
	 */
	public void empiler(E valeur) {
		Element element = new Element();
		element.valeur = valeur;
		element.suivant = tete;
		tete = element;
	}

	/**
	 * Dépile le dernier élément entré dans la pile.
	 */
	public void depiler() {
		if (!pileVide()) {
			Element element = tete;
			tete = tete.suivant;
			element = null;
		}
	}

	/**
	 * Redéfinit la méthode toString()
	 * @return Chaîne représentant les éléments entrés dans la Pile.
	 */
	public String toString() {
		String str = "";
		String separateur = " ";
		//
		Element element = tete;
		while (element != null) {
			str += element.valeur.toString() + separateur;
			element = element.suivant;
		}
		str = str.substring(0, str.length() - separateur.length());
		//
		return str;
	}
}
