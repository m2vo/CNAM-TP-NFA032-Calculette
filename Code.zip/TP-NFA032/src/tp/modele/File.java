 package tp.modele;

 /**
  * Représente une collection d'objets de type générique chaînés 
  * sur le principe FIFO (premier entré, premier sorti).
  * 
  * @author Michel DEVAUX
  * @version 1.1
  * @param <E> Type générique
  */
 
 public class File<E> {
 	
 	/**
 	 * Classe privée.</br> Représente un élément de la Pile composé <br/>
 	 * - d'une valeur de type générique <br/>
 	 * - d'une référence à l'élément suivant.
 	 */
 	private class Element {
 		public E valeur;
 		public Element suivant;
 	}

 	/**
 	 * Attributs
 	 */
 	private Element tete;
 	private Element queue;
 	
 	/**
 	 * Constructeur <br/>
 	 * Crée un nouvel objet de type File.
 	 */
 	public File() {
 		tete = null;
 		queue = null;
 	}
 	
 	/**
 	 * Teste si la File est vide.
 	 * @return TRUE si la file est vide.
 	 */
 	public boolean fileVide() {
 		return (tete == null);
 	}
 	
 	/**
 	 * Renvoie l'élément le plus ancien de la File (le premier élément entré).
 	 * @return Objet de type générique.</br>
 	 * Retourne NULL si la file est vide.
 	 */
 	public E lireFile() {
 		E elt = null;
 		if (!fileVide()) {
 			elt = tete.valeur;
 		}
 		return elt;
 	}
 	
 	/**
 	 * Enfile un nouvel élément à la queue de la File
 	 * @param elt Objet de type générique.
 	 */
 	public void enfiler(E elt) {
 		Element element = new Element();
 		element.valeur = elt;
 		element.suivant = null;
 		if (fileVide()) {
 			tete = element;
 			queue = element;
 		} else {
 			queue.suivant = element;
 			queue = element;
 		}
 	}
 	
 	/**
 	 * Défile l'élément le plus ancien de la File.
 	 */
 	public void defiler() {
 		if (!fileVide()) {
 			Element element = tete;
 			tete = tete.suivant;
 			element = null;
 		}
 	}
 	
 	/**
 	 * Redéfinit la méthode toString()
 	 * @return Chaîne représentant tous les éléments de la File.
 	 */
 	public String toString() {
 		String str = "";
 		String separateur = " ";
 		//
 		Element element = tete;
 		while (element != null) {
 			str += element.valeur.toString() + separateur;
 			element = element.suivant;
 		}
 		str = str.substring(0, str.length() - separateur.length());
 		//
 		return str;
 	}

 }
