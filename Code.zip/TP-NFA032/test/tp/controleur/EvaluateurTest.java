package tp.controleur;

import org.junit.Test;
import org.junit.Assert;

import tp.modele.ExceptionMath;
import tp.modele.ExceptionStruct;

/**
 * Batterie de tests JUnit
 * 
 * @author Michel Devaux Version 1.0
 */
public class EvaluateurTest {

	@Test(timeout = 1000)
	public void testCalculer01() 
			throws ExceptionStruct, ExceptionMath {
		// assetEquals(valeur attendue, valeur calculée, tolérance)
		Assert.assertEquals(5, Evaluateur.getEvaluateur()
			.traitement("5"), 0);
	}
	
	@Test(timeout = 1000)
	public void testCalculer02() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(5558, Evaluateur.getEvaluateur()
			.traitement("(5555+3)"), 0);
	}
	
	@Test(timeout = 1000)
	public void testCalculer03() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(8, Evaluateur.getEvaluateur()
			.traitement("(8)"), 0);
	}
	
	@Test(timeout = 1000)
	public void testCalculer04() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(5558,Evaluateur.getEvaluateur()
			.traitement("(3+5555)"), 0);
	}
	
	@Test(timeout = 1000)
	public void testCalculer05() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(25, Evaluateur.getEvaluateur()
			.traitement("(5*(2+3))"), 0);
	}
	
	@Test(timeout = 1000)
	public void testCalculer06() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(65536, Evaluateur.getEvaluateur()
			.traitement("((125+3)*512)"), 0);
	}
	
	@Test(timeout = 1000)
	public void testCalculer07() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(-2, Evaluateur.getEvaluateur()
			.traitement("(2*((((53-52)*1)/5)+(6-7)))"), 0);
	}
	
	@Test(expected = ExceptionMath.class, timeout = 1000)
	public void testCalculer08() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("(2*((((3-2)*1)/(17-((2*3)+11)))+(6-7)))");
	}
	
	@Test(timeout = 1000)
	public void testCalculer09() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(-2,Evaluateur.getEvaluateur()
			.traitement("(2*(( ((3-2)*1)/5)+(6-7)))"), 0);
	}
	
	@Test(expected = ExceptionStruct.class, timeout = 1000)
	public void testCalculer10() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("(2*(((((3-2)*1)/5)+(6-7)))");
	}
	
	@Test(expected = ExceptionStruct.class, timeout = 1000)
	public void testCalculer11()
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("(2*((((3-2)*1)/5))+(6-7))))");
	}

	// TESTS COMPLEMENTAIRES (PERSONNELS)

	@Test(expected = ExceptionStruct.class, timeout = 1000)
	public void testCalculer12() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("()");
	}
	
	@Test(expected = ExceptionStruct.class, timeout = 1000)
	public void testCalculer13() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("(5++3");
	}
	
	@Test(expected = ExceptionStruct.class, timeout = 1000)
	public void testCalculer14() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("(-53)");
	}
	
	@Test(timeout = 1000)
	public void testCalculer15() 
			throws ExceptionStruct, ExceptionMath {
		Assert.assertEquals(523, Evaluateur.getEvaluateur()
			.traitement("((523))"), 0);
	}
	
	@Test(expected = ExceptionMath.class, timeout = 1000)
	public void testCalculer16() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("(99999999999 + 2)");
	}
	
	@Test(expected = ExceptionMath.class, timeout = 1000)
	public void testCalculer17() 
			throws ExceptionStruct, ExceptionMath {
		int res = Evaluateur.getEvaluateur()
			.traitement("((123456*123456)*123456)");
	}
	
}
